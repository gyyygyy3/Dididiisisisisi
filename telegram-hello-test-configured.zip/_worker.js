const TELEGRAM_BOT_TOKEN = "8942095685:AAHxg-H_5wBE3E6PmHuwXtNluW3GByU9W_8";
const TELEGRAM_CHAT_ID = "8415581380";

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors });
    }

    const url = new URL(request.url);

    if (url.pathname === "/" && request.method === "GET") {
      return new Response(`<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>اختبار إرسال تيليجرام</title>
<style>
body{font-family:system-ui,sans-serif;max-width:560px;margin:48px auto;padding:0 18px;background:#f5f7fb;color:#172033}
main{background:#fff;border:1px solid #e1e6ef;border-radius:18px;padding:24px;box-shadow:0 8px 28px #15254a12}
h1{font-size:24px}p{line-height:1.8;color:#526078}
button{background:#229ed9;color:white;border:0;border-radius:12px;padding:13px 20px;font-size:16px;font-weight:700;cursor:pointer}
button:disabled{opacity:.6;cursor:wait}
#status{margin-top:18px;white-space:pre-wrap;overflow-wrap:anywhere}
.note{font-size:13px}
</style>
</head>
<body><main>
<h1>اختبار إرسال رسالة إلى تيليجرام</h1>
<p>اضغط الزر لإرسال كلمة «مرحبا» إلى البوت.</p>
<button id="send">إرسال «مرحبا»</button>
<div id="status" role="status" aria-live="polite"></div>
<p class="note">هذا المشروع يرسل رسالة نصية فقط ولا يستخدم الكاميرا أو الصور.</p>
</main>
<script>
const button=document.getElementById('send');
const status=document.getElementById('status');
button.addEventListener('click',async()=>{
  button.disabled=true; status.textContent='جارٍ الإرسال…';
  try{
    const r=await fetch('/send-hello',{method:'POST'});
    const data=await r.json();
    status.textContent=data.ok?'نجح الإرسال: أرسل تيليجرام الرسالة.':('فشل الإرسال: '+(data.error||'خطأ غير معروف'));
  }catch(e){status.textContent='تعذر الاتصال بالخادم. تأكد من نشر Worker وفتح الصفحة من نفس النطاق.';}
  finally{button.disabled=false;}
});
</script></body></html>`, {
        headers: { "Content-Type": "text/html; charset=utf-8", ...cors }
      });
    }

    if (url.pathname === "/send-hello" && request.method === "POST") {
      try {
        const telegramResponse = await fetch(
          `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              chat_id: TELEGRAM_CHAT_ID,
              text: "مرحبا"
            })
          }
        );
        const result = await telegramResponse.json();
        if (!telegramResponse.ok || !result.ok) {
          return Response.json({
            ok: false,
            error: result.description || `Telegram API returned HTTP ${telegramResponse.status}`
          }, { status: 502, headers: cors });
        }
        return Response.json({ ok: true, message_id: result.result?.message_id }, { headers: cors });
      } catch {
        return Response.json({ ok: false, error: "تعذر الاتصال بواجهة Telegram API." }, { status: 502, headers: cors });
      }
    }

    return new Response("Not found", { status: 404, headers: cors });
  }
};
